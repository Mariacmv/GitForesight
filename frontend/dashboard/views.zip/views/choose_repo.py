import os, json
from datetime import datetime, timezone
from urllib.parse import urlparse
from html import escape
from frontend.dashboard.views.first_analysis import render_primeira_analise
from frontend.dashboard.views.results_preview import render_resultados

import requests
import streamlit as st
import streamlit.components.v1 as components

from backend.app.github import fetch_repo_stats, fetch_many_stats
from components.cards import html_inline
from components.topbar import render_auth_footer, render_auth_topbar
from backend.database.repositories import salvar_instalacoes_github, salvar_repositorio_usuario, salvar_branch_repositorio
from backend.services.github_installation import listar_instalacoes_usuario, listar_repositorios_instalacao, listar_branches_instalacao

ETAPAS = [
    "Escolher repositório",
    "Primeira análise",
    "Explorar resultados",
]

STATS_LIMIT = 30
LISTA_ALTURA = 520 #rolagem de repositórios

def _token():
    return st.session_state.get("github_token") or os.getenv("GITHUB_TOKEN")

def _num(n):
    return f"{n:,}".replace(",", ".")


def _tempo_relativo(iso):
    if not iso:
        return "—"
    dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
    minutos = int((datetime.now(timezone.utc) - dt).total_seconds() // 60)
    if minutos < 60:
        return f"há {max(minutos, 1)} min"
    if minutos < 1440:
        return f"há {minutos // 60} h"
    dias = minutos // 1440
    return f"há {dias} dia" if dias == 1 else f"há {dias} dias"

def _selecionar(full_name):
    st.session_state.repo_sel = full_name

def _contas():
    user_id = st.session_state.get("user_id")
    user_token = st.session_state.get("github_user_token")

    if not user_id:
        st.error("DEBUG: user_id não encontrado.")
        return None

    if not user_token:
        st.error("DEBUG: github_user_token não encontrado.")
        return None

    try:
        instalacoes = listar_instalacoes_usuario(user_token)

        # st.write(
        #     "DEBUG — Instalações encontradas:",
        #     len(instalacoes)
        # )

        salvar_instalacoes_github(user_id, instalacoes)

        return instalacoes

    except requests.HTTPError as e:
        st.error(
            f"GitHub API: HTTP {e.response.status_code}"
        )

        st.write(
            "Resposta:",
            e.response.text[:500]
        )
        return None

    except Exception as e:
        st.error(
            f"Erro ao consultar instalações: "
            f"{type(e).__name__}: {e}"
        )
        return None

def _repos(conta):
    cache = st.session_state.setdefault("gh_repos", {})

    installation_id = conta["installation_id"]

    #print("DEBUG — Installation ID:", installation_id)

    if installation_id not in cache:
        cache[installation_id] = listar_repositorios_instalacao(
            installation_id
        )

    return cache[installation_id]    

def _detalhes(full_name):
    cache = st.session_state.setdefault("gh_detalhes", {})
    if full_name not in cache:
        cache[full_name] = fetch_repo_stats(full_name, _token())
    return cache[full_name]

def _stats(repos):
    cache = st.session_state.setdefault("gh_stats", {})
    faltam = [r["full_name"] for r in repos[:STATS_LIMIT] if r["full_name"] not in cache]
    if faltam:
        cache.update(fetch_many_stats(faltam, _token()))
    return cache

def _stepper(passo):
    itens = ""
    for n, nome in enumerate(ETAPAS, start=1):
        estado = "current" if n == passo else "done" if n < passo else "todo"
        simbolo = "✓" if estado == "done" else n
        itens += (
            f'<div class="step-item {estado}">'
            f'<div class="step-circle">{simbolo}</div>'
            f'<div class="step-text">{nome}</div>'
            f'</div>'
        )

    st.markdown(html_inline(f"""
        <div class="stepper-wrapper">
            <div class="steps-container">{itens}</div>
            <div class="step-counter">ETAPA {passo} DE {len(ETAPAS)}</div>
        </div>
    """), unsafe_allow_html=True)

def _linha_repo(r, selecionado, stats):
    tag = "Privado" if r["private"] else "Público"
    desc = escape(r["description"] or "Sem descrição")

    meta = f'<span><i class="lang-dot"></i>{escape(r["language"])}</span>'
    if stats.get("commits") is not None:
        meta += f'<span>{_num(stats["commits"])} commits</span>'
    if stats.get("contributors") is not None:
        meta += f'<span>{_num(stats["contributors"])} contribuidores</span>'
    meta += f'<span>Atualizado {_tempo_relativo(r["pushed_at"])}</span>'

    return html_inline(f"""
        <div class="repo-row {'selected' if selecionado else ''}">
            <span class="repo-radio"></span>
            <div class="repo-row-body">
                <div class="repo-row-top">
                    <span class="repo-row-name">{escape(r['full_name'])}</span>
                    <span class="repo-tag">{tag}</span>
                </div>
                <div class="repo-row-desc">{desc}</div>
                <div class="repo-row-meta">{meta}</div>
            </div>
            {'<span class="repo-check">✓</span>' if selecionado else ''}
        </div>
    """)

def _redirecionar_instalacao():
    url = st.secrets["GITHUB_INSTALL_URL"].strip()
    parsed = urlparse(url)

    if (
        parsed.scheme != "https"
        or parsed.hostname != "github.com"
        or not parsed.path.startswith("/apps/")
    ):
        st.error("URL de instalação da GitHub App inválida.")
        return

    st.info(
        "Redirecionando ao GitHub... "
        "Na próxima tela, escolha todos os repositórios "
        "ou apenas aqueles que deseja analisar."
    )

    st.markdown(
        f"""
        <meta http-equiv="refresh" content="0;url={url}">
        """,
        unsafe_allow_html=True,
    )

def _seletor_conta():
    #st.write("DEBUG — Página:", st.session_state.get("pagina"))
    #st.write("DEBUG — Autenticado:", st.session_state.get("autenticado"))
    # st.write(
    #     "DEBUG — Token GitHub disponível:",
    #     bool(st.session_state.get("github_user_token"))
    # )
    user_token = st.session_state.get("github_user_token")

    if not user_token:
        st.error("Token GitHub não encontrado na sessão.")
        return None

    instalacoes = _contas()

    if instalacoes is None:
        st.error("Não foi possível verificar as instalações.")
        return None

    if not instalacoes:
        _redirecionar_instalacao()
        return None

    indice = st.selectbox(
        "Conta ou organização",
        options=range(len(instalacoes)),
        format_func=lambda i: (
            f"{instalacoes[i]['account_login']} · "
            f"{instalacoes[i]['account_type']}"
        ),
        key="conta_instalacao_sel",
    )

    return instalacoes[indice]

def _lista(conta):
    busca = st.text_input(
        "Buscar", key="repo_busca", label_visibility="collapsed",
        placeholder="Buscar por nome de repositório...",
    ).strip().lower()

    repos, stats = [], {}
    if conta is None:
        pass
    else:
        try:
            with st.spinner("Buscando repositórios..."):
                repos = _repos(conta)
                stats = _stats(repos)
        except ValueError as e:
            st.error(str(e))
        except requests.RequestException:
            st.error("Não foi possível consultar o GitHub. Verifique sua conexão.")

    filtrados = [r for r in repos if busca in r["full_name"].lower()]
    nomes = [r["full_name"] for r in filtrados]

    if st.session_state.get("repo_sel") not in nomes:
        st.session_state.repo_sel = nomes[0] if nomes else None

    st.markdown(html_inline(f"""
        <div class="repo-list-head">
            <span>{len(filtrados)} repositório{'s' if len(filtrados) != 1 else ''}</span>
            <span>Atualização recente ↓</span>
        </div>
    """), unsafe_allow_html=True)

    # Área com rolagem própria
    with st.container(height=LISTA_ALTURA, border=False, key="repo_list"):
        for i, r in enumerate(filtrados):
            with st.container(key=f"repo_row_{i}"):
                st.markdown(
                    _linha_repo(r, r["full_name"] == st.session_state.repo_sel,
                                stats.get(r["full_name"], {})),
                    unsafe_allow_html=True,
                )
                st.button(
                    f"Selecionar {r['full_name']}", key=f"pick_{i}",
                    on_click=_selecionar, args=(r["full_name"],),
                )

        if conta is not None and not filtrados:
            st.caption("Nenhum repositório encontrado.")

    nome = st.session_state.get("repo_sel")

    col_botao, col_dica = st.columns([1, 1], vertical_alignment="center")

    with col_botao:
        continuar = st.button(
            "Continuar para a análise", key="continuar_analise",
            type="primary", icon=":material/arrow_forward:", disabled=not nome,
        )

    with col_dica:
        st.markdown(
            '<div class="repo-list-foot">Não encontrou o projeto? '
            'Confira a conta ou organização selecionada.</div>',
            unsafe_allow_html=True,
        )

    
    if continuar: #salvando o(s) repositório(s) escolhido(s) pelo usuário
        user_id = st.session_state.get("user_id")

        if not user_id:
            st.error("Sua sessão expirou. Entre novamente.")
            return

        try:
            with st.spinner("Consultando o repositório..."):
                info = _detalhes(nome)

                url = f"https://github.com/{nome}"

                salvar_repositorio_usuario(
                    user_id=user_id,
                    nome=nome,
                    url=url,
                )

        except ValueError as e:
            st.error(str(e))
            return
        except requests.RequestException:
            st.error(
                "Não foi possível consultar o GitHub. "
                "Verifique sua conexão e tente novamente."
            )
            return
        except Exception:
            st.error("Não foi possível salvar o repositório selecionado.")
            return

        repo_selecionado = next(
            (repo for repo in repos if repo["full_name"] == nome),
            None,
        )

        if repo_selecionado is None:
            st.error("Não foi possível localizar o repositório selecionado.")
            return

        # Completa com o que a lista de repositórios já sabe
        for chave in ("full_name", "private", "language", "default_branch"):
            if info.get(chave) is None and repo_selecionado.get(chave) is not None:
                info[chave] = repo_selecionado[chave]

        info.setdefault("language", "—")
        info.setdefault("commits", 0)
        info.setdefault("contributors", 0)
        info["branches"] = listar_branches_instalacao(
            conta["installation_id"],
            nome,
        )
        info["url"] = url

        st.session_state.repo_info = info
        st.session_state.repo_sel = nome
        st.session_state.repo_url = url
        st.session_state.branch = repo_selecionado["default_branch"]
        salvar_branch_repositorio(
            user_id=user_id,
            url=url,
            branch=st.session_state.branch,
        )
        st.session_state.passo = 2
        st.session_state.analise = "pronta"

        st.rerun()


def _etapa_1():
    with st.container(key="repo_picker"):
        conta = _seletor_conta()
        if conta is None:
            return
        _lista(conta)

def processar_retorno_instalacao():
    installation_id = st.query_params.get("installation_id")
    setup_action = st.query_params.get("setup_action")

    if not installation_id or setup_action not in ("install", "update"):
        return False

    try:
        installation_id = int(installation_id)
    except (ValueError, TypeError):
        st.query_params.clear()
        st.error("Identificador de instalação inválido.")
        return True

    st.query_params.clear()

    for chave in (
        "gh_repos",
        "gh_detalhes",
        "conta_instalacao_sel",
    ):
        st.session_state.pop(chave, None)

    st.session_state["retorno_instalacao_pendente"] = True
    st.session_state["installation_id_pendente"] = installation_id
    st.session_state["pagina"] = "choose_repo"
    st.session_state["passo"] = 1

    return True

def render():
    render_auth_topbar(mostrar_usuario=True)

    st.markdown(
        """
        <style>
        [data-testid="stSidebar"],
        [data-testid="stSidebarCollapsedControl"],
        [data-testid="stToolbar"],
        [data-testid="stDecoration"] { display: none !important; }

        [data-testid="stMainBlockContainer"] {
            max-width: 1248px;
            padding-top: 96px !important;
            padding-bottom: 112px !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    if "passo" not in st.session_state:
        st.session_state.passo = 1

    if st.session_state.passo > 1 and "repo_info" not in st.session_state:
        st.session_state.passo = 1


    passo = st.session_state.passo

    with st.container(key="repo_zoom"):
        _stepper(passo)

        espaco_etapa = st.empty()

        with espaco_etapa.container():

            if passo == 1:
                st.title("Boas-vindas ao GitForesight.")
                st.caption(
                    "Qual repositório vamos analisar primeiro? "
                    "Escolha a conta, o projeto e a branch para começar."
                )
                _etapa_1()

            elif passo == 2:
                render_primeira_analise()

            elif passo == 3:
                render_resultados()

    render_auth_footer()